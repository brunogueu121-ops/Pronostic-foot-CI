PRONOSTICFOOT CI — Version 2 (prototype technique)

Fichiers:
- index.html : interface mobile, filtres, pages matchs/stats/admin/réglages.
- manifest.webmanifest + sw.js : base d'installation PWA.
- backend/README.txt : architecture et contrat API pour les vraies données et l'administration sécurisée.
- ANDROID_BUILD.txt : étapes pour produire un APK Android.

Données réelles:
Cette version essaie de joindre le backend que tu configures dans Réglages. Sans backend, elle n'invente pas de rencontres. Il faut encore choisir et connecter un fournisseur de données sportives.

Administration:
L'interface d'administration est volontairement désactivée tant que l'authentification serveur n'est pas en place. Ne mets jamais un mot de passe ou une clé API dans index.html.

Android:
Le ZIP n'est pas un APK. La compilation APK nécessite un projet Android/Capacitor, Android Studio, des tests et une signature.

Le dossier `backend/` contient maintenant un squelette Node.js de proxy de données et de connexion admin. Il ne suffit pas à lui seul pour une mise en production: variables d'environnement, compte admin provisionné, stockage de session persistant, base de données et tests restent nécessaires.
